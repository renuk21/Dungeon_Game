package view;

import java.awt.LayoutManager;
import javax.swing.JPanel;

class DungeonPanel extends JPanel {

  public DungeonPanel(LayoutManager layout) {
    super(layout);
  }


}
