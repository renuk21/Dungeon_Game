package dungeoncomponents;

/**
 * Enumeration for Otyugh's health status.
 */
public enum Health {
  HEALTHY, INJURED, DEAD,
}
