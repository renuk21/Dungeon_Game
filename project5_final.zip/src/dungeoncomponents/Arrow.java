package dungeoncomponents;

/**
 * Enumeration for types of arrows.
 */
public enum Arrow {
  CROOKED,
}
