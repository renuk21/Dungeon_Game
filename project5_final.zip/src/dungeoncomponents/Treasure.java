package dungeoncomponents;

/**
 * Enumeration for types of treasure.
 */
public enum Treasure {
  DIAMOND, RUBY, SAPPHIRE,
}
